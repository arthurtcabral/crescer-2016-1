﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MegamanLista1
{
    public abstract class Robo
    {

        private int vida = 100;
        private int ataque = 5;
        private int defesa = 0;

        public abstract string Nome { get; }
        protected virtual int Vida
        {
            get
            {
                return vida;
            }
        }
        protected virtual int Ataque {
            get
            {
                return ataque;
            }
        }
        protected virtual int Defesa
        {
            get
            {
                return defesa;
            }
        }
        public void Atacar(Robo robo)
        {
            vida = vida - (ataque - robo.defesa);
        }
    }
}
